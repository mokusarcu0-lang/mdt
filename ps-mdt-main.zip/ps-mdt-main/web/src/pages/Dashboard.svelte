<script lang="ts">
	import { onMount, onDestroy } from "svelte";
	import { formatDate, formatTime, toDate } from "../utils/datetime";
	import { fetchNui } from "../utils/fetchNui";
	import { NUI_EVENTS } from "../constants/nuiEvents";
	import type { createTabService } from "../services/tabService.svelte";
	import { openReportInEditor } from "../stores/reportsStore";
	import { mdtStore } from "../stores/mdtStore";
	import { PRIORITY_COLORS } from "../constants";
	import { createDashboardService } from "../services/dashboardService.svelte";
	import ReportItem from "../components/dashboard/ReportItem.svelte";
	import DispatchStatusWidget from "../components/dashboard/DispatchStatusWidget.svelte";
	import type { PlayerData } from "@/interfaces/IPlayerData";

	interface ActiveBolo {
		id: number;
		reportId: string;
		name: string;
		type: string;
		notes: string;
	}

	import type { JobType } from "../interfaces/IUser";

	let {
		signOut,
		playerData,
		tabService,
		jobType = 'leo',
	}: {
		signOut: () => void;
		playerData: PlayerData | null;
		tabService: ReturnType<typeof createTabService>;
		jobType?: JobType;
	} = $props();

	let isLEO = $derived(jobType === 'leo');
	let isDOJ = $derived(jobType === 'doj');
	let isLEOJob = $derived(jobType !== 'doj' && jobType !== 'ems');

	// ── Upcoming hearings / open cases helpers ──
	function hearingWhen(v: string | number | undefined): string {
		const d = toDate(v);
		if (!d) return v ? String(v) : "";
		const now = new Date();
		const sameDay = d.toDateString() === now.toDateString();
		const tomorrow = new Date(now); tomorrow.setDate(now.getDate() + 1);
		const isTomorrow = d.toDateString() === tomorrow.toDateString();
		const hm = formatTime(d);
		if (sameDay) return `Today ${hm}`;
		if (isTomorrow) return `Tomorrow ${hm}`;
		return `${formatDate(d)} ${hm}`;
	}
	function hearingCatColor(cat?: string): string {
		if (cat === "training") return "#22c55e";
		if (cat === "meeting") return "#f59e0b";
		if (cat === "other") return "#a78bfa";
		return "#60a5fa"; // court
	}
	function casePrioColor(p?: string): string {
		if (p === "high") return "#ef4444";
		if (p === "low") return "#22c55e";
		return "#f59e0b";
	}

	// DOJ dashboard data
	let dojWarrantReviews = $state<any[]>([]);
	let dojCourtCases = $state<any[]>([]);
	let dojCourtOrders = $state<any[]>([]);

	async function loadDojDashboard() {
		if (!isDOJ) return;
		const [reviews, cases, orders] = await Promise.all([
			fetchNui<any>(NUI_EVENTS.DOJ.GET_WARRANT_REQUESTS, { status: 'pending', limit: 5 }, []),
			fetchNui<any>(NUI_EVENTS.DOJ.GET_COURT_CASES, { limit: 5 }, []),
			fetchNui<any>(NUI_EVENTS.DOJ.GET_COURT_ORDERS, { limit: 5 }, []),
		]);
		dojWarrantReviews = Array.isArray(reviews) ? reviews.slice(0, 5) : [];
		dojCourtCases = Array.isArray(cases) ? cases.slice(0, 5) : [];
		dojCourtOrders = Array.isArray(orders) ? orders.slice(0, 5) : [];
	}

	// Services
	const dashboardService = createDashboardService() as ReturnType<
		typeof createDashboardService
	> & {
		activeBolos?: ActiveBolo[];

		recentReportsHasMore?: boolean;
		loadMoreRecentReports?: () => Promise<void>;
	};

	// Impound at a glance (the server sends this on the dashboard payload).
	let impound = $derived(
		dashboardService.usageMetrics?.impound ?? { held: 0, outstanding: 0, oldestDays: 0, impoundedLast7: 0 }
	);

	// UI state
	let reportOpened: number | null = $state(null);

	// Pagination
	const PAGE_SIZE = 10;
	let warrantPage = $state(0);
	let boloPage = $state(0);

	let warrantTotalPages = $derived(Math.max(1, Math.ceil((dashboardService.activeWarrants ?? []).length / PAGE_SIZE)));
	let boloTotalPages = $derived(Math.max(1, Math.ceil((dashboardService.activeBolos || []).length / PAGE_SIZE)));
	let pagedWarrants = $derived((dashboardService.activeWarrants ?? []).slice(warrantPage * PAGE_SIZE, (warrantPage + 1) * PAGE_SIZE));
	let pagedBolos = $derived((dashboardService.activeBolos || []).slice(boloPage * PAGE_SIZE, (boloPage + 1) * PAGE_SIZE));

	// ── Callsign ──
	const EMPTY_CALLSIGN_VALUES = new Set(['', 'NIL', 'NO CALLSIGN', 'NONE', 'NULL']);

	function isValidCallsign(cs: unknown): boolean {
		if (cs == null || cs === '') return false;
		const upper = String(cs).trim().toUpperCase();
		if (EMPTY_CALLSIGN_VALUES.has(upper)) return false;
		if (!upper.startsWith('PD-')) return false;
		return upper.length > 3;
	}

	let callsignModalOpen = $state(false);
	let callsignInput = $state("");
	let callsignSaving = $state(false);
	let callsignLoading = $state(true);
	let localCallsign = $state("");

	async function fetchCallsign() {
		callsignLoading = true;
		const result = await fetchNui<{ callsign?: string }>(
			NUI_EVENTS.DASHBOARD.GET_CALLSIGN,
			{ citizenid: playerData?.citizenid },
			{ callsign: '' }
		);
		const cs = result?.callsign != null ? String(result.callsign).trim() : "";
		if (isValidCallsign(cs)) {
			localCallsign = cs;
		}
		callsignLoading = false;
	}

	let hasCallsign = $derived(isValidCallsign(localCallsign));

	function openCallsignModal() {
		callsignInput = hasCallsign ? localCallsign : "PD-";
		callsignModalOpen = true;
	}

	function closeCallsignModal() {
		callsignModalOpen = false;
		callsignInput = "";
	}

	function handleCallsignInput(e: Event) {
		let val = (e.target as HTMLInputElement).value
			.toUpperCase()
			.replace(/[^A-Z0-9\-]/g, "");

		if (!val.startsWith('PD-')) {
			if (val.startsWith('PD')) {
				val = 'PD-' + val.slice(2);
			} else if (val.startsWith('P')) {
				val = 'PD-' + val.slice(1).replace(/^D-?/, '');
			} else {
				val = 'PD-' + val.replace(/^[PD\-]+/, '');
			}
		}

		callsignInput = val.slice(0, 6);
		(e.target as HTMLInputElement).value = callsignInput;
	}

	async function saveCallsign() {
		const cs = callsignInput.trim();
		if (!isValidCallsign(cs) || callsignSaving) return;
		callsignSaving = true;
		try {
			await fetchNui(NUI_EVENTS.DASHBOARD.SET_CALLSIGN, { callsign: cs, citizenid: playerData?.citizenid });
			localCallsign = cs;
			closeCallsignModal();
		} catch {
			/* silent */
		} finally {
			callsignSaving = false;
		}
	}

	onMount(async () => {
		dashboardService.initialize();
		dashboardService.startCarouselTimer();
		loadDojDashboard();
		await fetchCallsign();
	});

	onDestroy(() => {
		dashboardService.destroy();
	});

	function viewBolo(boloId: number) {
		tabService.setActiveTab("BOLOs");
		const activeInstance = tabService.getActiveInstance();
		if (activeInstance) tabService.setInstanceTab(activeInstance.id, "BOLOs");
	}

	function viewReport(reportId: string) {
		openReportInEditor(reportId);
		tabService.setActiveTab("Reports");
		const activeInstance = tabService.getActiveInstance();
		if (activeInstance) tabService.setInstanceTab(activeInstance.id, "Reports");
	}


	function toggleDuty() {
		fetchNui(NUI_EVENTS.NAVIGATION.TOGGLE_DUTY);
	}

	function handleSignOut() {
		mdtStore.reset();
		signOut();
	}



	function openReport(id: number) {
		reportOpened = reportOpened === id ? null : id;
	}

	async function loadMoreReports() {
		await dashboardService.loadMoreRecentReports();
	}

	function openWarrant(reportId: number) {
		if (!reportId) return;
		openReportInEditor(reportId);
		tabService.setActiveTab("Reports");
		const activeInstance = tabService.getActiveInstance();
		if (activeInstance) tabService.setInstanceTab(activeInstance.id, "Reports");
	}

	function getCarouselDotOpacity(index: number): number {
		if (index === dashboardService.currentBulletinIndex) {
			return 0.8 - dashboardService.carouselProgress * 0.5;
		}
		return 0.3;
	}

	let currentBulletinContent = $derived(
		dashboardService.bulletins[dashboardService.currentBulletinIndex]?.content ?? dashboardService.bulletinContent ?? ""
	);
</script>

<div class="dashboard">
	<div class="top-section">
		<div class="stats-strip">
			<!-- Rank -->
			<div class="stat-item">
				<div class="stat-icon rank-icon">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"/></svg>
				</div>
				<div class="stat-content">
					<span class="stat-value">{dashboardService.jobInfo.rank}</span>
					<span class="stat-label">{dashboardService.jobInfo.payRate}</span>
				</div>
			</div>
			<div class="stat-divider"></div>

			<!-- Reports -->
			<div class="stat-item">
				<div class="stat-icon reports-icon">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
				</div>
				<div class="stat-content">
					<span class="stat-value">
						{dashboardService.reportsInfo.totalThisWeek}
						<span class="stat-change" class:positive={dashboardService.reportsInfo.changeFromLastWeek > 0} class:negative={dashboardService.reportsInfo.changeFromLastWeek < 0}>
							{#if dashboardService.reportsInfo.changeFromLastWeek > 0}+{/if}{dashboardService.reportsInfo.changeFromLastWeek}
						</span>
					</span>
					<span class="stat-label">Reports this week</span>
				</div>
			</div>
			<div class="stat-divider"></div>

			<!-- Active Units -->
			<div class="stat-item">
				<div class="stat-icon units-icon">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 00-3-3.87"/><path d="M16 3.13a4 4 0 010 7.75"/></svg>
				</div>
				<div class="stat-content">
					<span class="stat-value">{dashboardService.activeUnits.count} <span class="stat-badge">On Duty</span></span>
					<span class="stat-label">Active units</span>
				</div>
			</div>
			<div class="stat-divider"></div>

			<!-- Impound -->
			{#if impound.held > 0 || impound.outstanding > 0}
				<div class="stat-item" title={impound.oldestDays > 0
					? `Oldest vehicle has been held for ${impound.oldestDays} day${impound.oldestDays === 1 ? '' : 's'}`
					: 'Vehicles currently held in impound'}>
					<div class="stat-icon impound-icon">
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="1" y="3" width="15" height="13"/><polygon points="16 8 20 8 23 11 23 16 16 16 16 8"/><circle cx="5.5" cy="18.5" r="2.5"/><circle cx="18.5" cy="18.5" r="2.5"/></svg>
					</div>
					<div class="stat-content">
						<span class="stat-value">
							{impound.held}
							{#if impound.outstanding > 0}
								<span class="stat-badge owed">${impound.outstanding.toLocaleString()} due</span>
							{/if}
						</span>
						<span class="stat-label">
							In impound{#if impound.oldestDays > 0} · oldest {impound.oldestDays}d{/if}
						</span>
					</div>
				</div>
				<div class="stat-divider"></div>
			{/if}

			<!-- Officer status breakdown (dispatch) -->
			<div class="stat-item">
				<div class="stat-content">
					<DispatchStatusWidget />
				</div>
			</div>
			<div class="stat-divider"></div>

			<!-- Bulletin with tooltip -->
			<div class="stat-item bulletin-item">
				<div class="stat-icon bulletin-icon">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 17H2a3 3 0 006 0h8a3 3 0 006 0zm0 0V5a2 2 0 00-2-2H4a2 2 0 00-2 2v12"/></svg>
				</div>
				<div class="stat-content bulletin-content">
					{#if dashboardService.bulletins.length > 0}
						<span class="bulletin-text">{currentBulletinContent}</span>
						{#if dashboardService.bulletins.length > 1}
							<div class="carousel-dots">
								{#each dashboardService.bulletins as _, index}
									<button
										class="carousel-dot"
										class:active={index === dashboardService.currentBulletinIndex}
										style="opacity: {getCarouselDotOpacity(index)}"
										onclick={() => dashboardService.goToBulletin(index)}
										aria-label="Go to bulletin {index + 1}"
									></button>
								{/each}
							</div>
						{/if}
						{#if currentBulletinContent}
							<div class="bulletin-tooltip">{currentBulletinContent}</div>
						{/if}
					{:else}
						<span class="bulletin-empty">No active bulletins</span>
					{/if}
				</div>
			</div>
			<div class="stat-divider"></div>

			<!-- Callsign -->
			{#if !callsignLoading}
				{#if hasCallsign}
					<button class="callsign-display" onclick={openCallsignModal} title="Change callsign">
						<div class="stat-icon callsign-icon">
							<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="5" width="20" height="14" rx="2"/><circle cx="8" cy="12" r="2"/><path d="M14 9h4M14 12h4M14 15h2"/></svg>
						</div>
						<div class="stat-content">
							<span class="stat-value callsign-value">{localCallsign}</span>
							<span class="stat-label">Callsign</span>
						</div>
					</button>
				{:else}
					<div class="callsign-warn">
						<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="cs-warn-icon"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
						<span class="cs-warn-text">No callsign set</span>
						<button class="cs-warn-btn" onclick={openCallsignModal}>Set Callsign</button>
					</div>
				{/if}
				<div class="stat-divider"></div>
			{/if}

			<!-- Quick Actions -->
			<div class="quick-actions">
				<button class="qa-btn qa-duty" onclick={toggleDuty} title="Toggle Duty">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v4m0 12v4M4.93 4.93l2.83 2.83m8.48 8.48l2.83 2.83M2 12h4m12 0h4M4.93 19.07l2.83-2.83m8.48-8.48l2.83-2.83"/></svg>
				</button>
				<button class="qa-btn qa-signout" onclick={handleSignOut} title="Sign Out">
					<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></svg>
				</button>
			</div>
		</div>
	</div>

	<!-- Main Content Grid -->
	<div class="main-grid">
		{#if isLEO}
		<div class="column">
			<div class="panel">
				<div class="panel-header">
					<span class="panel-title">Warrants</span>
					<span class="panel-count">{dashboardService.activeWarrants.length}</span>
				</div>
				<div class="panel-body">
					{#if dashboardService.activeWarrants.length === 0}
						<div class="empty-state">No active warrants</div>
					{:else}
						{#each pagedWarrants as warrant}
							<button class="list-item" onclick={() => openWarrant(warrant.reportid)}>
								<div class="item-left">
									<span class="item-name">{warrant.name}</span>
									<span class="item-meta">#{warrant.reportid} · Exp. {formatDate(warrant.expirydate)}</span>
									<div class="pill-row">
										{#if warrant.felonies > 0}<span class="pill pill-red">{warrant.felonies} Felony</span>{/if}
										{#if warrant.misdemeanors > 0}<span class="pill pill-orange">{warrant.misdemeanors} Misd.</span>{/if}
										{#if warrant.infractions > 0}<span class="pill pill-green">{warrant.infractions} Infr.</span>{/if}
									</div>
								</div>
								<svg class="item-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
							</button>
						{/each}
					{/if}
				</div>
				{#if warrantTotalPages > 1}
					<div class="pager">
						<button class="pager-btn" disabled={warrantPage === 0} onclick={() => warrantPage--}>
							<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
						</button>
						<span class="pager-info">{warrantPage + 1}/{warrantTotalPages}</span>
						<button class="pager-btn" disabled={warrantPage >= warrantTotalPages - 1} onclick={() => warrantPage++}>
							<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
						</button>
					</div>
				{/if}
			</div>

			<div class="panel">
				<div class="panel-header">
					<span class="panel-title">BOLOs</span>
					<span class="panel-count">{(dashboardService.activeBolos || []).length}</span>
				</div>
				<div class="panel-body">
					{#if (dashboardService.activeBolos || []).length === 0}
						<div class="empty-state">No active BOLOs</div>
					{:else}
						{#each pagedBolos as bolo}
							<button class="list-item" onclick={() => viewBolo(bolo.id)}>
								<div class="item-left">
									<span class="item-name">{bolo.name}</span>
									<span class="item-meta">#{bolo.reportId} · <span class="pill pill-blue">{bolo.type}</span></span>
									{#if bolo.notes && bolo.notes.trim()}
										<span class="item-notes">{bolo.notes}</span>
									{/if}
								</div>
								<svg class="item-arrow" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
							</button>
						{/each}
					{/if}
				</div>
				{#if boloTotalPages > 1}
					<div class="pager">
						<button class="pager-btn" disabled={boloPage === 0} onclick={() => boloPage--}>
							<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="15 18 9 12 15 6"/></svg>
						</button>
						<span class="pager-info">{boloPage + 1}/{boloTotalPages}</span>
						<button class="pager-btn" disabled={boloPage >= boloTotalPages - 1} onclick={() => boloPage++}>
							<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="9 18 15 12 9 6"/></svg>
						</button>
					</div>
				{/if}
			</div>
		</div>
		{/if}

		<!-- Center: Recent Reports -->
		<div class="column">
			<div class="panel">
				<div class="panel-header">
					<span class="panel-title">Recent Reports</span>
					<span class="panel-count">{dashboardService.recentReports.length}</span>
				</div>
				<div class="panel-body">
					{#if dashboardService.recentReports.length === 0}
						<div class="empty-state">No recent reports</div>
					{:else}
						{#each dashboardService.recentReports as report}
							<ReportItem
								{report}
								isExpanded={reportOpened === report.id}
								onToggle={openReport}
								onNavigate={viewReport}
							/>
						{/each}
					{/if}
				</div>
				{#if dashboardService.recentReportsHasMore}
					<button class="load-more-btn" onclick={loadMoreReports}>Load more</button>
				{/if}
			</div>
		</div>

		<!-- Right: Dispatches or DOJ -->
		<div class="column">
			{#if isDOJ}
				<div class="panel">
					<div class="panel-header">
						<span class="panel-title">Pending Warrant Reviews</span>
						<span class="panel-count">{dojWarrantReviews.length}</span>
					</div>
					<div class="panel-body">
						{#if dojWarrantReviews.length === 0}
							<div class="empty-state">No pending warrants</div>
						{:else}
							{#each dojWarrantReviews as wr}
								<button class="list-item-btn" onclick={() => tabService.openTab('warrant_review')}>
									<span class="item-name">{wr.citizen_name || wr.citizenid}</span>
									<span class="item-meta">{wr.status || 'pending'} · {formatDate(wr.created_at)}</span>
								</button>
							{/each}
						{/if}
					</div>
				</div>
				<div class="panel">
					<div class="panel-header">
						<span class="panel-title">Court Cases</span>
						<span class="panel-count">{dojCourtCases.length}</span>
					</div>
					<div class="panel-body">
						{#if dojCourtCases.length === 0}
							<div class="empty-state">No court cases</div>
						{:else}
							{#each dojCourtCases as cc}
								<button class="list-item-btn" onclick={() => tabService.openTab('court_cases')}>
									<span class="item-name">{cc.title || cc.case_number}</span>
									<span class="item-meta">{cc.status} · {formatDate(cc.created_at || cc.filed_date)}</span>
								</button>
							{/each}
						{/if}
					</div>
				</div>
				<div class="panel">
					<div class="panel-header">
						<span class="panel-title">Court Orders</span>
						<span class="panel-count">{dojCourtOrders.length}</span>
					</div>
					<div class="panel-body">
						{#if dojCourtOrders.length === 0}
							<div class="empty-state">No court orders</div>
						{:else}
							{#each dojCourtOrders as co}
								<button class="list-item-btn" onclick={() => tabService.openTab('court_orders')}>
									<span class="item-name">{co.title || co.order_number}</span>
									<span class="item-meta">{co.status} · {formatDate(co.created_at)}</span>
								</button>
							{/each}
						{/if}
					</div>
				</div>
			{:else}
				<!-- Upcoming hearings (dispatches now live on the Map tab) -->
				<div class="panel" class:panel--half={isLEOJob}>
					<div class="panel-header">
						<span class="panel-title">Upcoming Hearings</span>
						<span class="panel-count">{dashboardService.upcomingHearings.length}</span>
					</div>
					<div class="panel-body">
						{#if dashboardService.upcomingHearings.length === 0}
							<span class="panel-empty">No upcoming appointments</span>
						{/if}
						{#each dashboardService.upcomingHearings as h (h.id)}
							<div class="list-row">
								<div class="priority-bar" style="background: {hearingCatColor(h.category)}"></div>
								<div class="item-left">
									<span class="item-name">{h.title}</span>
									<span class="item-meta">
										{hearingWhen(h.scheduled_at)}{#if h.location} · {h.location}{/if}{#if h.defendant_name} · {h.defendant_name}{/if}
									</span>
								</div>
								{#if h.status === "in_session"}
									<span class="live-pill">LIVE</span>
								{/if}
							</div>
						{/each}
					</div>
				</div>

				{#if isLEOJob}
					<div class="panel panel--half">
						<div class="panel-header">
							<span class="panel-title">Open Cases</span>
							<span class="panel-count">{dashboardService.openCases.length}</span>
						</div>
						<div class="panel-body">
							{#if dashboardService.openCases.length === 0}
								<span class="panel-empty">No open investigations</span>
							{/if}
							{#each dashboardService.openCases as c (c.id)}
								<div class="list-row">
									<div class="priority-bar" style="background: {casePrioColor(c.priority)}"></div>
									<div class="item-left">
										<span class="item-name">{c.case_number} · {c.title}</span>
										<span class="item-meta">{c.status === "in_progress" ? "In progress" : "Open"}{#if c.priority} · {c.priority} priority{/if}</span>
									</div>
								</div>
							{/each}
						</div>
					</div>
				{/if}
			{/if}
		</div>
	</div>

	<!-- Callsign Modal -->
	{#if callsignModalOpen}
		<!-- svelte-ignore a11y_click_events_have_key_events -->
		<!-- svelte-ignore a11y_no_static_element_interactions -->
		<div class="cs-modal-overlay" onclick={(e) => { if (e.target === e.currentTarget) closeCallsignModal(); }}>
			<div class="cs-modal" role="dialog" aria-modal="true" onclick={(e) => e.stopPropagation()}>
				<div class="cs-modal-header">
					<span class="cs-modal-title">{hasCallsign ? 'Change Callsign' : 'Set Callsign'}</span>
					<button class="cs-modal-close" onclick={closeCallsignModal} aria-label="Close">
						<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
					</button>
				</div>
				<div class="cs-modal-body">
					<span class="cs-input-label">Callsign</span>
					<input
						class="cs-input"
						type="text"
						placeholder="PD-01"
						value={callsignInput}
						oninput={handleCallsignInput}
						onkeydown={(e) => { if (e.key === 'Enter') saveCallsign(); if (e.key === 'Escape') closeCallsignModal(); }}
						maxlength={6}
						spellcheck={false}
						autofocus
					/>
					<span class="cs-hint">{callsignInput.length}/6 · format: PD-XX</span>
				</div>
				<div class="cs-modal-footer">
					<button class="cs-btn-cancel" onclick={closeCallsignModal} disabled={callsignSaving}>Cancel</button>
					<button class="cs-btn-confirm" onclick={saveCallsign} disabled={callsignSaving || !isValidCallsign(callsignInput)}>
						{callsignSaving ? "Saving..." : "Save"}
					</button>
				</div>
			</div>
		</div>
	{/if}
</div>

<style>
	.dashboard { display: flex; flex-direction: column; height: 100%; overflow: hidden; background: var(--card-dark-bg); }

	.top-section { flex-shrink: 0; border-bottom: 1px solid rgba(255, 255, 255, 0.06); }
	.stats-strip { display: flex; align-items: center; padding: 0 20px; height: 52px; gap: 0; }
	.stat-divider { width: 1px; height: 28px; background: rgba(255, 255, 255, 0.06); flex-shrink: 0; }
	.stat-item { display: flex; align-items: center; gap: 10px; padding: 0 16px; flex-shrink: 0; }
	.bulletin-item { flex: 1; min-width: 0; position: relative; }

	.stat-icon { width: 30px; height: 30px; border-radius: 8px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
	.rank-icon { background: rgba(168, 85, 247, 0.12); color: #a78bfa; }
	.reports-icon { background: rgba(16, 185, 129, 0.12); color: #34d399; }
	.units-icon { background: rgba(var(--accent-rgb), 0.12); color: #60a5fa; }

	.impound-icon {
		background: rgba(251, 191, 36, 0.1);
		color: rgba(252, 211, 77, 0.9);
	}

	.stat-badge.owed {
		background: rgba(239, 68, 68, 0.12);
		color: rgba(248, 113, 113, 0.95);
		font-variant-numeric: tabular-nums;
	}
	.bulletin-icon { background: rgba(251, 191, 36, 0.12); color: #fbbf24; }
	.callsign-icon { background: rgba(var(--accent-rgb), 0.12); color: #60a5fa; }

	.stat-content { display: flex; flex-direction: column; min-width: 0; }
	.bulletin-content { flex: 1; min-width: 0; }

	.stat-value { color: rgba(255, 255, 255, 0.9); font-size: 13px; font-weight: 600; line-height: 1.2; display: flex; align-items: center; gap: 6px; }
	.callsign-value { font-family: monospace; letter-spacing: 1px; color: #60a5fa; }
	.stat-label { color: rgba(255, 255, 255, 0.35); font-size: 10px; font-weight: 500; text-transform: uppercase; letter-spacing: 0.5px; }
	.stat-change { font-size: 11px; font-weight: 600; }
	.stat-change.positive { color: #34d399; }
	.stat-change.negative { color: #f87171; }
	.stat-badge { font-size: 9px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; background: rgba(var(--accent-rgb), 0.15); color: #60a5fa; padding: 1px 6px; border-radius: 3px; }

	/* Bulletin */
	.bulletin-text { color: rgba(255, 255, 255, 0.6); font-size: 12px; line-height: 1.3; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; display: block; }
	.bulletin-empty { color: rgba(255, 255, 255, 0.3); font-size: 11px; }
	.carousel-dots { display: flex; gap: 4px; margin-top: 2px; }
	.carousel-dot { width: 4px; height: 4px; border-radius: 50%; border: none; background: rgba(255, 255, 255, 0.8); cursor: pointer; padding: 0; transition: opacity 0.1s ease, transform 0.2s ease; }
	.carousel-dot.active { transform: scale(1.4); }
	.carousel-dot:hover { opacity: 0.9 !important; }

	/* Bulletin tooltip */
	.bulletin-tooltip {
		display: none;
		position: absolute;
		top: calc(100% + 10px);
		left: 0;
		background: #111113;
		border: 1px solid rgba(255, 255, 255, 0.12);
		border-radius: 5px;
		padding: 8px 12px;
		font-size: 11px;
		color: rgba(255, 255, 255, 0.92);
		line-height: 1.5;
		max-width: 320px;
		white-space: normal;
		word-break: break-word;
		z-index: 100;
		box-shadow: 0 8px 24px rgba(0, 0, 0, 0.6);
	}

	.bulletin-item:hover .bulletin-tooltip { display: block; }

	/* Callsign display */
	.callsign-display { display: flex; align-items: center; gap: 10px; padding: 0 16px; flex-shrink: 0; background: transparent; border: none; cursor: pointer; color: inherit; font: inherit; height: 100%; transition: background 0.12s; }
	.callsign-display:hover { background: rgba(255, 255, 255, 0.04); }

	/* Callsign warning */
	.callsign-warn { display: flex; align-items: center; gap: 6px; padding: 4px 10px; margin: 0 8px; background: rgba(245, 158, 11, 0.08); border: 1px solid rgba(245, 158, 11, 0.15); border-radius: 5px; flex-shrink: 0; }
	.cs-warn-icon { color: rgba(251, 191, 36, 0.7); flex-shrink: 0; }
	.cs-warn-text { color: rgba(251, 191, 36, 0.75); font-size: 11px; font-weight: 500; white-space: nowrap; }
	.cs-warn-btn { display: inline-flex; align-items: center; gap: 3px; padding: 2px 8px; border-radius: 3px; border: 1px solid rgba(251, 191, 36, 0.25); background: rgba(251, 191, 36, 0.1); color: rgba(251, 191, 36, 0.9); font-size: 10px; font-weight: 600; cursor: pointer; white-space: nowrap; transition: all 0.12s ease; margin-left: 2px; }
	.cs-warn-btn:hover { background: rgba(251, 191, 36, 0.2); border-color: rgba(251, 191, 36, 0.4); }

	/* Quick Actions */
	.quick-actions { display: flex; gap: 6px; padding-left: 16px; flex-shrink: 0; }
	.qa-btn { width: 32px; height: 32px; border-radius: 8px; display: flex; align-items: center; justify-content: center; cursor: pointer; transition: all 0.15s; border: 1px solid transparent; }
	.qa-duty { background: rgba(16, 185, 129, 0.1); color: #34d399; border-color: rgba(16, 185, 129, 0.15); }
	.qa-duty:hover { background: rgba(16, 185, 129, 0.2); border-color: rgba(16, 185, 129, 0.3); }
	.qa-signout { background: rgba(239, 68, 68, 0.08); color: #f87171; border-color: rgba(239, 68, 68, 0.1); }
	.qa-signout:hover { background: rgba(239, 68, 68, 0.15); border-color: rgba(239, 68, 68, 0.25); }

	/* Main Grid */
	.main-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; flex: 1; min-height: 0; gap: 12px; padding: 12px 16px 14px; }
	.column { display: flex; flex-direction: column; min-height: 0; gap: 12px; }

	/* Panels */
	.panel {
		display: flex;
		flex-direction: column;
		flex: 1;
		min-height: 0;
		overflow: hidden;
		background: rgba(255, 255, 255, 0.02);
		border: 1px solid rgba(255, 255, 255, 0.05);
		border-radius: 6px;
	}
	.panel--half { flex: 1 1 0; }
	.panel + .panel { border-top: 1px solid rgba(255, 255, 255, 0.06); }
	.panel-header { display: flex; align-items: center; gap: 8px; padding: 10px 14px 8px; flex-shrink: 0; border-bottom: 1px solid rgba(255, 255, 255, 0.04); }
	.panel-title { color: rgba(255, 255, 255, 0.4); font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 1px; }
	.panel-count { background: rgba(255, 255, 255, 0.06); color: rgba(255, 255, 255, 0.35); font-size: 10px; font-weight: 600; padding: 0 5px; border-radius: 4px; line-height: 16px; }

	.panel-body { flex: 1; min-height: 0; overflow-y: auto; padding: 8px 10px 10px; display: flex; flex-direction: column; gap: 2px; scrollbar-width: thin; scrollbar-color: rgba(255, 255, 255, 0.08) transparent; }

	/* Hearings / open cases rows + helpers */
	.list-row {
		display: flex;
		align-items: center;
		gap: 8px;
		padding: 7px 10px;
		border-radius: 5px;
		background: rgba(255, 255, 255, 0.015);
		border: 1px solid rgba(255, 255, 255, 0.03);
	}
	.panel-empty {
		font-size: 10px;
		color: rgba(255, 255, 255, 0.3);
		font-style: italic;
		padding: 8px 10px;
	}
	.live-pill {
		font-size: 8px;
		font-weight: 800;
		letter-spacing: 0.6px;
		color: rgba(248, 113, 113, 1);
		background: rgba(239, 68, 68, 0.12);
		border: 1px solid rgba(239, 68, 68, 0.35);
		padding: 1px 6px;
		border-radius: 3px;
		animation: livePulse 1.4s ease-in-out infinite;
	}
	@keyframes livePulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.45; } }
	.panel-body::-webkit-scrollbar { width: 3px; }
	.panel-body::-webkit-scrollbar-track { background: transparent; }
	.panel-body::-webkit-scrollbar-thumb { background: rgba(255, 255, 255, 0.08); border-radius: 2px; }

	/* List Items */
	.list-item { display: flex; align-items: center; gap: 8px; padding: 8px 10px; border-radius: 6px; background: transparent; border: none; cursor: pointer; transition: background 0.1s; text-align: left; color: inherit; font: inherit; width: 100%; }
	.list-item:hover { background: rgba(255, 255, 255, 0.04); }
	.item-left { display: flex; flex-direction: column; gap: 2px; flex: 1; min-width: 0; }
	.item-name { color: rgba(255, 255, 255, 0.85); font-size: 12px; font-weight: 500; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
	.item-meta { color: rgba(255, 255, 255, 0.3); font-size: 11px; display: flex; align-items: center; gap: 4px; }
	.item-notes { color: rgba(255, 255, 255, 0.35); font-size: 11px; line-height: 1.3; margin-top: 1px; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; }
	.item-arrow { color: rgba(255, 255, 255, 0.15); flex-shrink: 0; transition: color 0.12s; }
	.list-item:hover .item-arrow { color: rgba(255, 255, 255, 0.4); }

	/* Pills */
	.pill-row { display: flex; gap: 4px; margin-top: 3px; flex-wrap: wrap; }
	.pill { padding: 1px 5px; border-radius: 3px; font-size: 9px; font-weight: 600; letter-spacing: 0.2px; border: 1px solid transparent; }
	.pill-red { background: rgba(239, 68, 68, 0.12); color: #f87171; border-color: rgba(239, 68, 68, 0.15); }
	.pill-orange { background: rgba(245, 158, 11, 0.12); color: #fbbf24; border-color: rgba(245, 158, 11, 0.15); }
	.pill-green { background: rgba(16, 185, 129, 0.12); color: #34d399; border-color: rgba(16, 185, 129, 0.15); }
	.pill-blue { background: rgba(var(--accent-rgb), 0.12); color: #60a5fa; border-color: rgba(var(--accent-rgb), 0.15); }

	/* Pager */
	.pager { display: flex; align-items: center; justify-content: center; gap: 8px; padding: 6px 16px 10px; flex-shrink: 0; }
	.pager-btn { display: flex; align-items: center; justify-content: center; width: 22px; height: 22px; background: transparent; border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 4px; color: rgba(255, 255, 255, 0.35); cursor: pointer; transition: all 0.12s; }
	.pager-btn:hover:not(:disabled) { background: rgba(255, 255, 255, 0.06); color: rgba(255, 255, 255, 0.7); }
	.pager-btn:disabled { opacity: 0.2; cursor: default; }
	.pager-info { font-size: 10px; color: rgba(255, 255, 255, 0.35); font-weight: 500; }

	/* Empty & Load More */
	.empty-state { color: rgba(255, 255, 255, 0.2); font-size: 11px; text-align: center; padding: 24px 0; }
	.load-more-btn { background: transparent; color: rgba(255, 255, 255, 0.35); border: none; border-top: 1px solid rgba(255, 255, 255, 0.04); padding: 8px; font-size: 11px; font-weight: 500; cursor: pointer; transition: all 0.12s; text-align: center; flex-shrink: 0; }
	.load-more-btn:hover { color: rgba(255, 255, 255, 0.5); background: rgba(255, 255, 255, 0.02); }

	/* Dispatch */
	.priority-bar { width: 3px; height: 24px; border-radius: 2px; flex-shrink: 0; }

	.list-item-btn { display: flex; flex-direction: column; gap: 2px; width: 100%; padding: 8px 12px; background: none; border: none; border-bottom: 1px solid rgba(255, 255, 255, 0.04); cursor: pointer; text-align: left; color: inherit; }
	.list-item-btn:hover { background: rgba(255, 255, 255, 0.04); }

	/* Callsign Modal */
	.cs-modal-overlay { position: fixed; inset: 0; background: rgba(0, 0, 0, 0.7); backdrop-filter: blur(4px); display: flex; align-items: center; justify-content: center; z-index: 9999; }
	.cs-modal { background: var(--card-dark-bg); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 6px; width: min(320px, 92vw); display: flex; flex-direction: column; overflow: hidden; box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5); }
	.cs-modal-header { display: flex; align-items: center; gap: 8px; padding: 10px 16px; border-bottom: 1px solid rgba(255, 255, 255, 0.06); flex-shrink: 0; }
	.cs-modal-title { font-size: 12px; font-weight: 600; color: rgba(255, 255, 255, 0.85); }
	.cs-modal-close { display: flex; align-items: center; justify-content: center; background: transparent; color: rgba(255, 255, 255, 0.3); border: 1px solid rgba(255, 255, 255, 0.06); padding: 4px; border-radius: 3px; cursor: pointer; transition: all 0.1s; margin-left: auto; }
	.cs-modal-close:hover { color: rgba(255, 255, 255, 0.7); border-color: rgba(255, 255, 255, 0.1); }
	.cs-modal-body { padding: 14px 16px; display: flex; flex-direction: column; gap: 3px; }
	.cs-input-label { color: rgba(255, 255, 255, 0.35); font-size: 9px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.6px; }
	.cs-input { background: rgba(255, 255, 255, 0.03); border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 3px; padding: 5px 8px; color: rgba(255, 255, 255, 0.8); font-size: 13px; font-weight: 600; letter-spacing: 1.5px; font-family: inherit; text-transform: uppercase; width: 100%; box-sizing: border-box; transition: border-color 0.1s; }
	.cs-input:focus { outline: none; border-color: rgba(255, 255, 255, 0.1); }
	.cs-input::placeholder { color: rgba(255, 255, 255, 0.15); letter-spacing: 1.5px; font-weight: 400; }
	.cs-hint { color: rgba(255, 255, 255, 0.2); font-size: 9px; margin-top: 1px; }
	.cs-modal-footer { display: flex; justify-content: flex-end; gap: 6px; padding: 10px 16px; border-top: 1px solid rgba(255, 255, 255, 0.06); }
	.cs-btn-cancel { background: transparent; border: 1px solid rgba(255, 255, 255, 0.06); border-radius: 3px; padding: 4px 10px; color: rgba(255, 255, 255, 0.4); font-size: 10px; font-weight: 500; cursor: pointer; transition: all 0.1s; }
	.cs-btn-cancel:hover:not(:disabled) { color: rgba(255, 255, 255, 0.7); border-color: rgba(255, 255, 255, 0.1); }
	.cs-btn-cancel:disabled { opacity: 0.4; cursor: not-allowed; }
	.cs-btn-confirm { background: rgba(16, 185, 129, 0.06); color: rgba(52, 211, 153, 0.7); border: 1px solid rgba(16, 185, 129, 0.1); border-radius: 3px; padding: 4px 12px; font-size: 10px; font-weight: 600; cursor: pointer; transition: all 0.1s; }
	.cs-btn-confirm:hover:not(:disabled) { background: rgba(16, 185, 129, 0.12); color: rgba(110, 231, 183, 0.9); }
	.cs-btn-confirm:disabled { opacity: 0.4; cursor: not-allowed; }
</style>